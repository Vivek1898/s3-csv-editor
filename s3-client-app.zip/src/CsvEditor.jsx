import React, { useEffect, useState } from 'react';
import Papa from 'papaparse';
import { useLocation } from 'react-router-dom';
import { Table, Button, Input, Row, Col, Spin, message } from 'antd';
import './App.css';

function useQuery() {
    return new URLSearchParams(useLocation().search);
}

function CsvEditor() {
    const query = useQuery();
    const fileKey = query.get('fileKey');
    console.log(fileKey);
    const [csvData, setCsvData] = useState([]);
    const [editedCsvData, setEditedCsvData] = useState([]);
    const [loadingFileContent, setLoadingFileContent] = useState(false);
    const [savingFile, setSavingFile] = useState(false);

    useEffect(() => {
        setLoadingFileContent(true);
        fetch(`http://localhost:8000/download?key=${fileKey}`)
            .then(response => response.json())
            .then(data => {
                if (data.file_content) {
                    Papa.parse(data.file_content, {
                        complete: (result) => {
                            setCsvData(result.data);
                            setEditedCsvData(result.data);
                        },
                        header: false,
                    });
                }
            })
            .catch(error => {
                console.error('Error downloading file:', error);
            })
            .finally(() => {
                setLoadingFileContent(false);
            });
    }, [fileKey]);

    const handleEditChange = (rowIndex, columnIndex, value) => {
        const updatedData = [...editedCsvData];
        updatedData[rowIndex][columnIndex] = value;
        setEditedCsvData(updatedData);
    };

    const handleSave = () => {
        setSavingFile(true);
        const csvString = Papa.unparse(editedCsvData);
        const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
        const formData = new FormData();
        formData.append('file', blob, fileKey);

        fetch(`http://localhost:8000/update/file/v2?file_key=${fileKey}`, {  // Adjust the port if needed
            method: 'PUT',
            body: formData,
        })
            .then(response => response.json())
            .then(data => {
                if (data.message === "File updated successfully") {
                    message.success('File saved successfully!');
                } else {
                    message.error('Error saving file!');
                }
            })
            .catch(error => {
                message.error('Error saving file!');
                console.error('Error saving file:', error);
            })
            .finally(() => {
                setSavingFile(false);
            });
    };

    const addRow = () => {
        const newRow = new Array(csvData[0].length).fill("");
        setEditedCsvData([...editedCsvData, newRow]);
    };

    const addColumn = () => {
        const newColumnTitle = `Column ${csvData[0].length + 1}`;
        const updatedData = editedCsvData.map((row, rowIndex) => {
            if (rowIndex === 0) {
                return [...row, newColumnTitle];
            }
            return [...row, ""];
        });
        setCsvData(updatedData); // Update the original csvData as well
        setEditedCsvData(updatedData);
    };

    const deleteRow = (rowIndex) => {
        const updatedData = editedCsvData.filter((_, index) => index !== rowIndex + 1);
        setEditedCsvData(updatedData);
    };

    const deleteColumn = (colIndex) => {
        const updatedData = editedCsvData.map(row => row.filter((_, index) => index !== colIndex));
        setEditedCsvData(updatedData);
    };

    return (
        <div>
            <h2>Editing file: {fileKey}</h2>
            {loadingFileContent ? (
                <Spin />
            ) : (
                <Row gutter={[16, 16]} style={{ marginTop: 20 }}>
                    <Col span={24}>
                        <Button onClick={addRow} style={{ marginBottom: 10 }}>Add Row</Button>
                        <Button onClick={addColumn} style={{ marginBottom: 10, marginLeft: 10 }}>Add Column</Button>
                        <Table
                            dataSource={editedCsvData.slice(1).map((row, rowIndex) => ({
                                key: rowIndex,
                                ...row.reduce((acc, col, colIndex) => ({ ...acc, [editedCsvData[0][colIndex]]: col }), {}),
                            }))}
                            columns={editedCsvData?.[0]?.map((col, colIndex) => ({
                                title: (
                                    <div>
                                        {col} <Button size="small" onClick={() => deleteColumn(colIndex)}>Delete</Button>
                                    </div>
                                ),
                                dataIndex: col,
                                key: colIndex,
                                render: (text, record, rowIndex) => (
                                    <Input
                                        value={text}
                                        onChange={(e) => handleEditChange(rowIndex + 1, colIndex, e.target.value)}
                                    />
                                ),
                            }))}
                            pagination={false}
                            footer={() => (
                                <div>
                                    <Button onClick={handleSave} type="primary" loading={savingFile}>Save</Button>
                                </div>
                            )}
                        />
                    </Col>
                </Row>
            )}
        </div>
    );
}

export default CsvEditor;
